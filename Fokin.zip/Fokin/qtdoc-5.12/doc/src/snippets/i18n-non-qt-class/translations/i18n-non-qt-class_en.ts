<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>MyClass</name>
    <message>
        <location filename="../myclass.cpp" line="6"/>
        <source>Hello Qt!
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
