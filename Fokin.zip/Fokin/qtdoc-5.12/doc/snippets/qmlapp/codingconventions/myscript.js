function calculateWidth(parent)
{
    var w = parent.width / 3
    // ...
    // more javascript code
    // ...
    console.debug(w)
    return w
}
