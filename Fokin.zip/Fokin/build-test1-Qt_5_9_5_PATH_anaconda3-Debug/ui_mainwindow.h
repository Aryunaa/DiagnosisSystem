/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *action;
    QAction *action_2;
    QAction *action_3;
    QAction *action_4;
    QAction *action_5;
    QAction *action_6;
    QAction *action_7;
    QAction *action_8;
    QAction *action_9;
    QAction *action_10;
    QAction *action_12;
    QAction *action_15;
    QAction *action_16;
    QWidget *centralWidget;
    QTableView *tableView;
    QLabel *label;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QTextEdit *txt;
    QTableView *tableView_2;
    QLabel *label_2;
    QTableWidget *tableWidget;
    QSpinBox *spinBox;
    QLabel *label_3;
    QPushButton *pushButton_3;
    QTextEdit *textEdit;
    QPushButton *pushButton_4;
    QMenuBar *menuBar;
    QMenu *menu;
    QMenu *menu_2;
    QMenu *menu_3;
    QMenu *menu_4;
    QMenu *menu_5;
    QMenu *menu_7;
    QMenu *menu_6;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1131, 691);
        QIcon icon;
        icon.addFile(QStringLiteral("../cute_ico/sgmu.ico"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setDocumentMode(false);
        action = new QAction(MainWindow);
        action->setObjectName(QStringLiteral("action"));
        action->setCheckable(true);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../cute_ico/icons8-\320\276\321\202\320\272\321\200\321\213\321\202\321\214-\320\264\320\276\320\272\321\203\320\274\320\265\320\275\321\202-64.png"), QSize(), QIcon::Normal, QIcon::Off);
        action->setIcon(icon1);
        action_2 = new QAction(MainWindow);
        action_2->setObjectName(QStringLiteral("action_2"));
        action_2->setCheckable(true);
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/cute_ico/icons8-\320\262\321\213\321\205\320\276\320\264-64.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_2->setIcon(icon2);
        action_3 = new QAction(MainWindow);
        action_3->setObjectName(QStringLiteral("action_3"));
        action_3->setEnabled(false);
        action_4 = new QAction(MainWindow);
        action_4->setObjectName(QStringLiteral("action_4"));
        action_4->setEnabled(false);
        action_5 = new QAction(MainWindow);
        action_5->setObjectName(QStringLiteral("action_5"));
        action_5->setCheckable(true);
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/cute_ico/icons8-\321\201\321\202\321\203\320\264\320\265\320\275\321\202-64.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_5->setIcon(icon3);
        action_6 = new QAction(MainWindow);
        action_6->setObjectName(QStringLiteral("action_6"));
        action_7 = new QAction(MainWindow);
        action_7->setObjectName(QStringLiteral("action_7"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/cute_ico/icons8-\320\270\320\275\321\204\320\276\321\200\320\274\320\260\321\206\320\270\321\217-64(1).png"), QSize(), QIcon::Normal, QIcon::Off);
        action_7->setIcon(icon4);
        action_8 = new QAction(MainWindow);
        action_8->setObjectName(QStringLiteral("action_8"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/cute_ico/icons8-\321\215\320\273.-\320\260\320\264\321\200\320\265\321\201-64.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_8->setIcon(icon5);
        action_9 = new QAction(MainWindow);
        action_9->setObjectName(QStringLiteral("action_9"));
        action_10 = new QAction(MainWindow);
        action_10->setObjectName(QStringLiteral("action_10"));
        action_10->setEnabled(false);
        action_12 = new QAction(MainWindow);
        action_12->setObjectName(QStringLiteral("action_12"));
        action_12->setCheckable(true);
        action_12->setChecked(false);
        action_12->setEnabled(false);
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/cute_ico/icons8-\321\201\321\202\320\260\321\202\320\270\321\201\321\202\320\270\320\272\320\260-64.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_12->setIcon(icon6);
        action_12->setShortcutContext(Qt::WindowShortcut);
        action_12->setMenuRole(QAction::TextHeuristicRole);
        action_12->setPriority(QAction::NormalPriority);
        action_15 = new QAction(MainWindow);
        action_15->setObjectName(QStringLiteral("action_15"));
        action_15->setEnabled(false);
        action_16 = new QAction(MainWindow);
        action_16->setObjectName(QStringLiteral("action_16"));
        action_16->setEnabled(false);
        action_16->setMenuRole(QAction::TextHeuristicRole);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        tableView = new QTableView(centralWidget);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(0, 0, 501, 351));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(980, 270, 121, 17));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setEnabled(false);
        pushButton->setGeometry(QRect(30, 460, 121, 25));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setEnabled(false);
        pushButton_2->setGeometry(QRect(30, 500, 121, 25));
        txt = new QTextEdit(centralWidget);
        txt->setObjectName(QStringLiteral("txt"));
        txt->setGeometry(QRect(610, 50, 361, 151));
        txt->setReadOnly(true);
        tableView_2 = new QTableView(centralWidget);
        tableView_2->setObjectName(QStringLiteral("tableView_2"));
        tableView_2->setGeometry(QRect(610, 230, 361, 192));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(980, 330, 91, 17));
        tableWidget = new QTableWidget(centralWidget);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));
        tableWidget->setEnabled(false);
        tableWidget->setGeometry(QRect(190, 440, 311, 81));
        spinBox = new QSpinBox(centralWidget);
        spinBox->setObjectName(QStringLiteral("spinBox"));
        spinBox->setEnabled(false);
        spinBox->setGeometry(QRect(920, 460, 48, 26));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setEnabled(false);
        label_3->setGeometry(QRect(980, 460, 91, 21));
        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setEnabled(false);
        pushButton_3->setGeometry(QRect(920, 490, 181, 31));
        textEdit = new QTextEdit(centralWidget);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setEnabled(false);
        textEdit->setGeometry(QRect(610, 460, 291, 141));
        pushButton_4 = new QPushButton(centralWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setEnabled(false);
        pushButton_4->setGeometry(QRect(920, 540, 181, 31));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1131, 22));
        menu = new QMenu(menuBar);
        menu->setObjectName(QStringLiteral("menu"));
        menu_2 = new QMenu(menuBar);
        menu_2->setObjectName(QStringLiteral("menu_2"));
        menu_2->setTearOffEnabled(false);
        menu_2->setToolTipsVisible(true);
        menu_3 = new QMenu(menuBar);
        menu_3->setObjectName(QStringLiteral("menu_3"));
        menu_4 = new QMenu(menuBar);
        menu_4->setObjectName(QStringLiteral("menu_4"));
        menu_5 = new QMenu(menuBar);
        menu_5->setObjectName(QStringLiteral("menu_5"));
        menu_7 = new QMenu(menu_5);
        menu_7->setObjectName(QStringLiteral("menu_7"));
        menu_6 = new QMenu(menuBar);
        menu_6->setObjectName(QStringLiteral("menu_6"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menu->menuAction());
        menuBar->addAction(menu_2->menuAction());
        menuBar->addAction(menu_3->menuAction());
        menuBar->addAction(menu_4->menuAction());
        menuBar->addAction(menu_5->menuAction());
        menuBar->addAction(menu_6->menuAction());
        menu->addAction(action);
        menu->addAction(action_2);
        menu->addSeparator();
        menu_2->addAction(action_12);
        menu_3->addAction(action_3);
        menu_3->addAction(action_4);
        menu_4->addAction(action_10);
        menu_5->addAction(menu_7->menuAction());
        menu_7->addSeparator();
        menu_7->addSeparator();
        menu_7->addAction(action_15);
        menu_7->addSeparator();
        menu_7->addAction(action_16);
        menu_6->addAction(action_5);
        menu_6->addAction(action_6);
        menu_6->addAction(action_7);
        menu_6->addAction(action_8);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Disease Diagnosis System. prototype", Q_NULLPTR));
        action->setText(QApplication::translate("MainWindow", "\320\236\321\202\320\272\321\200\321\213\321\202\321\214", Q_NULLPTR));
#ifndef QT_NO_SHORTCUT
        action->setShortcut(QApplication::translate("MainWindow", "Ctrl+O", Q_NULLPTR));
#endif // QT_NO_SHORTCUT
        action_2->setText(QApplication::translate("MainWindow", "\320\222\321\213\320\271\321\202\320\270 \320\270\320\267 \320\277\321\200\320\276\320\263\321\200\320\260\320\274\320\274\321\213", Q_NULLPTR));
#ifndef QT_NO_SHORTCUT
        action_2->setShortcut(QApplication::translate("MainWindow", "Ctrl+Q", Q_NULLPTR));
#endif // QT_NO_SHORTCUT
        action_3->setText(QApplication::translate("MainWindow", "\320\237\321\200\320\270\320\275\321\206\320\270\320\277 \321\200\320\260\321\201\321\201\321\202\320\276\321\217\320\275\320\270\320\271", Q_NULLPTR));
        action_4->setText(QApplication::translate("MainWindow", "\320\237\320\265\321\200\321\206\320\265\320\277\321\202\321\200\320\276\320\275", Q_NULLPTR));
        action_5->setText(QApplication::translate("MainWindow", "\320\220\320\262\321\202\320\276\321\200", Q_NULLPTR));
        action_6->setText(QApplication::translate("MainWindow", "\320\237\321\200\320\270\320\275\321\206\320\270\320\277\321\213 \320\274\320\265\321\202\320\276\320\264\320\276\320\262", Q_NULLPTR));
        action_7->setText(QApplication::translate("MainWindow", "\320\230\320\275\321\201\321\202\321\200\321\203\320\272\321\206\320\270\321\217", Q_NULLPTR));
        action_8->setText(QApplication::translate("MainWindow", "\320\241\321\201\321\213\320\273\320\272\320\270 \320\270 \321\200\320\265\321\201\321\203\321\200\321\201\321\213", Q_NULLPTR));
        action_9->setText(QApplication::translate("MainWindow", "\320\237\321\200\320\270\320\275\321\206\320\270\320\277\321\213 \320\274\320\265\321\202\320\276\320\264\320\276\320\262", Q_NULLPTR));
        action_10->setText(QApplication::translate("MainWindow", "\320\276\321\206\320\265\320\275\320\270\321\202\321\214", Q_NULLPTR));
        action_12->setText(QApplication::translate("MainWindow", "\321\200\320\260\321\201\321\201\321\207\320\270\321\202\320\260\321\202\321\214", Q_NULLPTR));
        action_15->setText(QApplication::translate("MainWindow", "\320\274\320\265\321\202\320\276\320\264 \320\233\320\224\320\244", Q_NULLPTR));
        action_16->setText(QApplication::translate("MainWindow", "\320\274\320\265\321\202\320\276\320\264 \320\277\320\265\321\200\321\206\320\265\320\277\321\202\321\200\320\276\320\275", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "\320\246\320\265\320\275\321\202\321\200\321\213 \320\272\320\273\320\260\321\201\321\201\320\276\320\262", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "\320\262\320\262\320\265\321\201\321\202\320\270 \321\201\320\273\321\203\321\207\320\260\320\271", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MainWindow", "\321\201\320\273\321\203\321\207\320\260\320\271 \320\262\320\262\320\265\320\264\321\221\320\275", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "\320\224\320\270\321\201\320\277\320\265\321\200\321\201\320\270\320\270", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "\320\222\320\262\320\265\320\264\320\270\321\202\320\265 \320\241", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("MainWindow", "\320\241 \320\262\320\262\320\265\320\264\321\221\320\275", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("MainWindow", "\320\277\321\200\320\276\320\264\320\276\320\273\320\266\320\270\321\202\321\214 \320\276\320\261\321\203\321\207\320\265\320\275\320\270\320\265", Q_NULLPTR));
        menu->setTitle(QApplication::translate("MainWindow", "\320\244\320\260\320\271\320\273", Q_NULLPTR));
        menu_2->setTitle(QApplication::translate("MainWindow", "\320\236\321\206\320\265\320\275\320\272\320\260 \321\205\320\260\321\200\320\260\320\272\321\202\320\265\321\200\320\270\321\201\321\202\320\270\320\272", Q_NULLPTR));
        menu_3->setTitle(QApplication::translate("MainWindow", "\320\236\320\261\321\203\321\207\320\265\320\275\320\270\320\265 ", Q_NULLPTR));
        menu_4->setTitle(QApplication::translate("MainWindow", "\320\236\321\206\320\265\320\275\320\272\320\260 \320\270\320\275\321\204\320\276\321\200\320\274\320\260\321\202\320\270\320\262\320\275\320\276\321\201\321\202\320\270 \320\277\321\200\320\270\320\267\320\275\320\260\320\272\320\276\320\262", Q_NULLPTR));
        menu_5->setTitle(QApplication::translate("MainWindow", "\320\240\320\260\321\201\320\277\320\276\320\267\320\275\320\260\321\202\321\214 \320\275\320\276\320\262\321\213\320\271", Q_NULLPTR));
        menu_7->setTitle(QApplication::translate("MainWindow", "\320\262\321\213\320\261\320\265\321\200\320\270\321\202\320\265 \320\274\320\265\321\202\320\276\320\264", Q_NULLPTR));
        menu_6->setTitle(QApplication::translate("MainWindow", "\320\237\320\276\320\274\320\276\321\211\321\214", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
